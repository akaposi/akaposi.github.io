Igy lehet pdf fajlt generalni: latexmk -pdf funprod.tex
